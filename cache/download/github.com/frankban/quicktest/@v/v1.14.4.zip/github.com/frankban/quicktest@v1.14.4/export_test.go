// Licensed under the MIT license, see LICENSE file for details.

package quicktest

var (
	Prefixf        = prefixf
	TestingVerbose = &testingVerbose
)
