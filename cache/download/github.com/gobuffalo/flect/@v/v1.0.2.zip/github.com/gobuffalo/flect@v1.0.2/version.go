package flect

//Version holds Flect version number
const Version = "v1.0.0"
