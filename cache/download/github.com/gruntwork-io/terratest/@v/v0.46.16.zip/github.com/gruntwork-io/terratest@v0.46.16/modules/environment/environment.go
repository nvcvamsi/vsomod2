// Package environment provides utility functions for interacting with the OS environment (e.g environment variables).
package environment
