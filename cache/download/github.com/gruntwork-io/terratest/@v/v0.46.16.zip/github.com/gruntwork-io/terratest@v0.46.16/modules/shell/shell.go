// Package shell allows to run commands in a shell.
package shell
