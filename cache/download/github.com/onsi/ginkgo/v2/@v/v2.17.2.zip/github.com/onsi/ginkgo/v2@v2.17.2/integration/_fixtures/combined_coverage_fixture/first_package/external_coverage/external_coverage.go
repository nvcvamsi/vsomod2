package external_coverage

func Tested() string {
	return "tested"
}

func Untested() string {
	return "untested"
}
