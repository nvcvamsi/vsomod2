// SVG pan and zoom library.
// See copyright notice in string constant below.

package svgpan

import _ "embed"

// https://github.com/aleofreddi/svgpan

//go:embed svgpan.js
var JSSource string
