# API serialization compatibility tests

This directory tree contains serialized API objects in json, yaml, and protobuf formats.